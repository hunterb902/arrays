#ifndef FUNCTIONS_H
#define FUNCTIONS_H

void readFromFile();
bool isIntegerInArray(int size, int target);
int modifyIntValue(int index, int newValue);
void modifyArray(int newVal);
void removeOrReplace(int index, int replaceValue);
void printArray();
#endif
