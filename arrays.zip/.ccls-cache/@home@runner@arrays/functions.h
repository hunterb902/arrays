#ifndef FUNCTIONS_H
#define FUNCTIONS_H

void readFromFile();
bool isIntegerInArray(int arr[], int size, int target);

#endif
