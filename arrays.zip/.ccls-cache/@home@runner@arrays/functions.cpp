#include "functions.h"
#include <fstream>
#include "functions.h"
#include <fstream>
#include <iostream>
#include <string>
#include <sstream>
void readFromFile() {
    std::ifstream inputFile("A1input.txt");
    std::string line;
    if (inputFile.is_open()) {
        while (inputFile) {
            // Process each line from the file
            int arr[100];
            std::istringstream iss(line);
            for (int i = 0; i < 100; i++) {
                iss >> arr[i];
                std::cout << arr[i] << std::endl;  // Print each element of the array
            }
        }
        inputFile.close();  // This should be outside the while loop
    }
}
bool isIntegerInArray(int arr[], int size, int target) {
  std::cout << "enter an integer you would like to find";
  std::cin >> target;
    for (int i = 0; i < size; i++) {
        if (arr[i] == target) {
            return true;
        }
    }
    return false;
}