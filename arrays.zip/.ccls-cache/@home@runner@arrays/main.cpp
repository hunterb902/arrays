#include "functions.h"
#include <iostream>
#include <string>
using namespace std;
int main() {
    readFromFile();
    return 0;
  
}
