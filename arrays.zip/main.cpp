#include "functions.h"
#include <iostream>
#include <string>
using namespace std;
int main() {
    int target = 0; //All variables used in main
    int index = 0;
    int newvalue = 0;
    int replaceValue;
    readFromFile(); //documentation for all function will be within functions.cpp
    cout << endl << "enter an integer you would like to find   ";
    cin >> target; //user input for target
      bool result = isIntegerInArray(99, target);
      if (result) { //if the integer is in the array, it will print the index
      } else {
          cout << "The integer is not in the array." << endl;
        
    return 0;
  
}
      cout << "Enter the index of the integer you would like to modify: ";
      cin >> index; //user input for index
      cout << "Enter the new value for the integer: ";
      cin >> newvalue; //user input for new value
      modifyIntValue(index, newvalue);
      cout << "Enter the new value you would like to have appended to the end of the array: ";
      cin >> newvalue; //user input for new value
        modifyArray(newvalue);
        cout << "Enter the index you would like to remove or replace: ";
        cin >> index; //user input for index
        cout << "Enter the value you would like use (0 to replace any other int to remove): ";
        
        cin >> replaceValue; //user input for replace value
        removeOrReplace(index,replaceValue);
        printArray(); //prints the array after all changes are made
}
