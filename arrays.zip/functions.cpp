#include "functions.h"
#include <fstream>
#include <iostream>
#include <string>
#include <sstream>
using namespace std;
int size = 100;// Declare size ass a global cariable
int arr[101]; // Declare arr as a global variable
void readFromFile()  { // Function to read from file
    int index = 0;
    ifstream inputFile("A1input.txt");
    string line;
    if (inputFile.is_open()) {
      while (getline(inputFile, line)) {
          istringstream iss(line);
          int num;
          while (iss >> num) {
              arr[index] = num;
              index++;
          }
      }
      for (int i = 0; i < index; i++)
        {
          cout << arr[i] << " ";
        }
        inputFile.close();  // This should be outside the while loop
    }
}
bool isIntegerInArray(int size, int target) { // Function to check if integer is in array
    for (int i = 0; i < size; i++) {
        if (arr[i] == target) {
          cout << "The integer is in the array. At index " << i << endl;
            return true;
            
        }
    }
    return false;
}
int modifyIntValue(int index, int newValue) { // Function to modify integer value
    int oldValue = 0;
  try {
      if(index < size) { // Check if index is within array bounds
          oldValue = arr[index];
          arr[index] = newValue;
          cout << "The integer at index " << index << " was modified from " << oldValue << " to " << newValue << endl;
      } else {
          throw "Index out of bounds";
      }
  } catch (const char* msg) { // Catch any exceptions
      cerr << msg << endl;
  }
    return oldValue;
}
void modifyArray(int newVal) // Function to modify array
{
  try { // Try block to catch any exceptions
      if (size < 101) { // Check if array is not full
          arr[size] = newVal;
          size++;
          cout << "The new value " << newVal << " was added to the array at index " << size - 1 << endl;
      } else {
          throw "Array size limit reached";
      }
  } catch (const char* msg) {
      cerr << msg << endl;
  }
}
void removeOrReplace(int index, int replaceValue) { // Function to remove or replace integer
    if (replaceValue == 0) {
        arr[index] = 0;
    } else {
        for (int i = index; i < size - 1; i++) {
            arr[i] = arr[i + 1];
        }
        size--;
    }
}
    void printArray(){ // Function to print array
    for (int i = 0; i < size; i++)
      {
        cout << arr[i] << " ";
      }
  }


